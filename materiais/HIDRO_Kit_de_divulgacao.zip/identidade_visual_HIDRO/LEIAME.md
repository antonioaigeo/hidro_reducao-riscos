# Identidade visual do HIDRO: guia rápido

## Conteúdo
| Pasta | Arquivos | Uso |
|---|---|---|
| `logo/` | horizontal, vertical e com mascote (fundo escuro e claro), ícone quadrado, ícone redondo (perfil), gota transparente; SVG da logo horizontal | Site, itch.io, slides, perfis |
| `redes_sociais/` | Arte 1 (Instagram feed 1080x1350), Arte 2 e 2B (Stories 1080x1920), Arte 3 (Facebook 1200x630) | Divulgação |
| `whatsapp/` | Cartão 1080x1080 | Enviar em conversas e grupos (o link vai na mensagem) |
| `reels/` | Capa com título e capa sem texto, 1080x1920 | Capa de Reel |
| `itch_io/` | Capas (B emblema, A cena, C animada), banner 1280x400 (e 2560x800), background e embed BG 1920x1080, e o guia `COMO_USAR.md` | Página do jogo no itch.io |
| `textos/` | Legendas, mensagens de WhatsApp, textos alternativos e hashtags | Publicação |

## Escolhas de tamanho
- **Instagram feed:** 1080x1350 (4:5). Também serve no Facebook.
- **Stories/Reels:** 1080x1920 (9:16). Deixe livres ~250 px no topo e na base (interface do app). Nas capas de Reel, o título fica na área central para sobreviver ao recorte da grade do perfil.
- **Facebook (postagem com link):** 1200x630 (1,91:1).
- **WhatsApp:** quadrado 1080x1080, com texto grande para ler em miniatura. O WhatsApp comprime imagens: por isso os textos são grandes e simples.
- **itch.io (capa):** 630x500. Na listagem aparece pequena, então logo e título são grandes.
Tamanhos e regras das plataformas mudam: confirme no momento de publicar.

## Paleta
Azul-marinho `#0F1B2E` | Azul-céu `#2A9FD6` | Ciano `#42C2F5` | Dourado `#F5C451` | Coral `#E5533D` | Verde `#2FA36B` | Gelo `#F3F8FC`

## Tipografia
Títulos das artes: **Poppins** (Bold e Medium), fonte livre (SIL Open Font License). O logotipo "HIDRO" é desenhado em pixel-art e não depende de fonte. No SVG, o subtítulo "Redução de Riscos" usa Poppins: instale a fonte para ver igual.

## Uso da logo
- Fundo escuro: `fundo_escuro`. Fundo claro: `fundo_claro`.
- Deixe ao redor da logo uma margem igual à altura da letra "H".
- Não estique, não gire e não troque as cores. Largura mínima recomendada: 200 px (horizontal).
- Perfil de Instagram/Facebook: use o ícone redondo ou quadrado.

## Créditos e direitos
Jogo, logotipo e artes: Antonio Idêrlian Pereira de Sousa. Personagens e cenas foram montados com os sprites do jogo. O licenciamento está em definição; até lá, uso apenas para divulgação do jogo, com crédito.
