# Imagens para a página do jogo no itch.io

## Onde cada arquivo entra
| Campo no itch.io | Arquivo | Observações |
|---|---|---|
| **Cover image** (Edit game) | pasta `capa/`: **B emblema** (mais legível em tamanho pequeno), A cena, ou C animada (GIF) | 630x500 é a medida recomendada (mínimo 315x250). Os arquivos `1260x1000` são versões 2x, mais nítidas. Escolha uma só. |
| **Banner** (Edit theme) | **`itch_banner_1280x400.png`** (ou `2560x800`, mais nítido) | A largura do banner deve ser igual à do jogo na página. Com o jogo em 1280x720 a coluna tem 1280 px; um banner de 960 px deixa faixas vazias dos lados. O nome HIDRO já está na imagem, porque o banner substitui o título. |
| **Background** (Edit theme) | `itch_background_1920x1080.png` | Fica atrás da página. Só aparece nas laterais e varia com a largura da janela de cada visitante, por isso não tem personagens (seriam cortados). |
| **Embed BG** (Edit theme) | `itch_embed_bg_1920x1080.png` | Aparece atrás da moldura do jogo. |
| Banner antigo | `itch_banner_960x300.png` | Só serve se você deixar o jogo com largura 960. |

## O que foi observado numa página real
- O **Embed BG** é mostrado em **tamanho real e centralizado** na moldura. Com o jogo em 1280x720, aparece o retângulo x 320-1600, y 180-900 da imagem de 1920x1080. A arte foi desenhada para esse recorte: logo no topo, o meio livre para o botão "Run game", e personagens nas laterais.
- Se você mudar o tamanho do jogo (por exemplo, para 1024x576), o recorte muda. Me avise que eu ajusto a arte e o banner.
- A **coluna de conteúdo** (BG2) acompanha a largura do jogo, e o banner não se estica sozinho. Por isso o banner deve ter a mesma largura.

## Como enviar
1. Abra a página pública do seu jogo, logado. 2. Clique em **Edit theme**. 3. Em **Images**, faça o **Upload** de Banner, Background e Embed BG. 4. Clique em **Save**.

## Cores sugeridas (mesmo painel Edit theme)
Tema escuro, para casar com o banner:
- **BG color** `#0F1B2E`   **BG2 color** `#1B2C4A` (com BG2 Alpha em 90% a 100%)
- **Text** `#F3F8FC`   **Link** `#42C2F5`   **Buttons** `#F5C451`   **Headers** `#F5C451`
Com BG2 escuro, qualquer faixa restante ao lado do banner se funde ao fundo.

## Firme e incerto
Nomes dos campos e medidas de cover e banner vêm da documentação e de guias do itch.io. O comportamento do Embed BG (tamanho real, centralizado) foi conferido em uma captura da sua página. Formatos aceitos: PNG, JPG e GIF, até 3 MB cada.


## Sobre a capa
- Na listagem do itch.io a capa aparece em cerca de 315x250. Por isso a logo é grande e não há texto miúdo. Os quatro ícones coloridos representam alagamento, enxurrada, enchente e deslizamento.
- A opção C é um GIF de 2 segundos em loop (a chuva cai, a água sobe e desce, o Hidro balança), com menos de 1 MB. Pelo que conheço, o itch.io aceita GIF na capa; se recusar, use a A ou a B.
