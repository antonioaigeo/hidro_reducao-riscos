# Legendas prontas, textos alternativos e hashtags

## ARTE 1 – Instagram (feed, 1080 x 1350)
**Legenda**
O que você faria se a chuva não parasse? 🌧️

O HIDRO é um jogo educativo em que você vira o Hidro e precisa decidir, com o relógio correndo, como proteger a casa, a rua e a comunidade em quatro situações: alagamento, enxurrada, enchente e deslizamento.

✔ Funciona no navegador (PC, celular e tablet)
✔ Pensado para a escola: quiz, mito ou verdade, glossário e medalhas
✔ Ensina o protocolo: proteja-se, avise a Defesa Civil (199) e aja com segurança

Link na bio para jogar.
Jogo criado por Antonio Idêrlian Pereira de Sousa.

**Texto alternativo**
Personagem de pixel-art com capa de chuva amarela em uma rua alagada, sob chuva forte. Título: "O que você faria se a chuva não parasse?". Jogo educativo HIDRO, para jogar no navegador.

## ARTE 2 – Stories (enquete, 1080 x 1920)
**Como usar:** poste e adicione o adesivo de ENQUETE no espaço vazio abaixo do personagem (entre o "Seu Antônio" e a frase "Vote na enquete"). Opções sugeridas: **VERDADE** / **MITO**. No dia seguinte, poste a ARTE 2B com a resposta.
**Texto alternativo**
Senhor idoso de pixel-art diz: "É só água da chuva, então não faz mal andar na rua alagada." Mito ou verdade?

## ARTE 2B – Stories (resposta, 1080 x 1920)
**Texto alternativo**
Resposta: é mito. A água do alagamento pode ter esgoto, lixo, buracos escondidos e fios energizados. Nunca ande na água, desligue a energia e avise a Defesa Civil: 199.

## ARTE 3 – Facebook (1200 x 630)
**Legenda**
Em uma emergência com chuva forte: 1) proteja-se, 2) avise a Defesa Civil (199) e 3) aja com segurança. No jogo HIDRO você treina essas decisões em quatro cenários: alagamento, enxurrada, enchente e deslizamento. Joga-se direto no navegador, no computador ou no celular. 👉 Link nos comentários.
**Texto alternativo**
Arte com o título "Em uma emergência: proteja-se, avise e aja", três ícones (capacete, telefone e escudo) e o personagem Hidro de capa amarela numa rua alagada. Logo do jogo HIDRO.

## WHATSAPP – cartão (1080 x 1080)
Envie a imagem e, na legenda ou logo abaixo, cole o link do jogo (a imagem não tem link clicável).

**Mensagem para grupos (famílias, professores, comunidade)**
🌧️ Você sabe o que fazer quando a chuva não para?
O HIDRO é um jogo educativo que ensina a diferença entre alagamento, enxurrada, enchente e deslizamento e o passo a passo para se proteger: proteja-se, avise a Defesa Civil (199) e aja com segurança.
Joga-se no navegador, no celular ou no computador: [COLE O LINK AQUI]
Compartilhe com a sua família e a sua turma!

**Mensagem curta (para alunos)**
Já jogou o HIDRO? Você é o Hidro e precisa proteger a rua e a comunidade antes que a água suba. Testa aí: [COLE O LINK AQUI]

**Texto alternativo**
Cartão do jogo HIDRO com o título "Aprenda a se proteger quando a chuva não para" e quatro cenas do jogo: alagamento, enxurrada, enchente e deslizamento.

## REEL – capa (1080 x 1920)
Há duas versões: `reel_capa` (com o título "O que fazer quando a chuva não para?") e `reel_capa_sem_texto` (para você escrever outro título no editor do Instagram).
**Como colocar a capa:** ao publicar o Reel, toque em "Editar capa" > "Adicionar da galeria" e escolha a imagem. Depois ajuste o corte do perfil (a grade recorta as bordas): o título já está na área central segura.
**Legenda sugerida**
O que fazer quando a chuva não para? 🌧️ Proteja-se, avise a Defesa Civil (199) e aja com segurança. Treine essas decisões no jogo HIDRO: link na bio.
**Ideias de vídeo (15 a 30 s)**
1) Mostre o Hidro ligando para o 199 no jogo. 2) Mostre a enxurrada e a passarela. 3) Termine com "Proteja-se, avise, aja" e o link na bio.

## Hashtags (escolha de 8 a 12)
#HIDRO #JogoEducativo #EducaçãoParaRiscos #DefesaCivil #RiscosDeDesastres #Alagamento #Enxurrada #Enchente #Deslizamento #Geografia #EducaçãoBásica #ProfessoresBrasil #Escola #Prevenção

## Antes de publicar
- Confirme o link do jogo (itch.io) e coloque-o na bio do Instagram, nos comentários do Facebook e nas mensagens do WhatsApp.
- Os telefones citados (199 Defesa Civil, 193 Bombeiros, 192 SAMU) são nacionais; confirme serviços de alerta locais.
